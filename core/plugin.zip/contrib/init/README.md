Sample configuration files for:
```
SystemD: mubdid.service
Upstart: mubdid.conf
OpenRC:  mubdid.openrc
         mubdid.openrcconf
CentOS:  mubdid.init
macOS:    org.mubdi.mubdid.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
