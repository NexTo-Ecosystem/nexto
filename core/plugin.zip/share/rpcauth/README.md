RPC Tools
---------------------

### [RPCAuth](/share/rpcauth) ###

Create login credentials for a JSON-RPC user.

Usage:

    ./rpcauth.py <username>

in which case the script will generate a password. To specify a custom password do:

    ./rpcauth.py <username> <password>
