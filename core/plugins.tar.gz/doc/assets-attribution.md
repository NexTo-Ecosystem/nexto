The following is a list of assets used in the mubdi source and their proper attribution.

Jonas Schnelli
-----------------------

### Info
* Designer: Jonas Schnelli (based on the original mubdi logo from Bitboy)
* License: MIT

### Assets Used
	src/qt/res/icons/mubdi.icns, src/qt/res/src/mubdi.svg,
	src/qt/res/src/mubdi.ico, src/qt/res/src/mubdi.png,
	src/qt/res/src/mubdi_testnet.png, docs/mubdi_logo_doxygen.png,
	src/qt/res/images/splash.png, src/qt/res/images/splash_testnet.png
